package domain.member;

import domain.sys.SysUser;
import sys.tags.CmTag;

import java.io.Serializable;
import java.util.Date;

public class MemberAbroadView implements Serializable {
    public SysUser getUser(){
        return CmTag.getUserById(userId);
    }

    private Integer id;

    private String lsh;

    private String gzzh;

    private String gj;

    private String jfly;

    private String cgjlb;

    private String cgjfs;

    private String yqdw;

    private String yqdwdz;

    private String yqr;

    private String sqrzc;

    private String sqrsjh;

    private String sqryx;

    private Date yjcfsj;

    private Date ygsj;

    private Integer yjtlts;

    private Date sjcfsj;

    private Date sgsj;

    private Integer sjtlts;

    private Date yq1s;

    private Date yq1z;

    private Date yq2s;

    private Date yq2z;

    private Date pzwh;

    private String cgjzt;

    private Integer userId;

    private String realname;

    private String code;

    private Byte gender;

    private Integer partyId;

    private Integer branchId;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLsh() {
        return lsh;
    }

    public void setLsh(String lsh) {
        this.lsh = lsh == null ? null : lsh.trim();
    }

    public String getGzzh() {
        return gzzh;
    }

    public void setGzzh(String gzzh) {
        this.gzzh = gzzh == null ? null : gzzh.trim();
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj == null ? null : gj.trim();
    }

    public String getJfly() {
        return jfly;
    }

    public void setJfly(String jfly) {
        this.jfly = jfly == null ? null : jfly.trim();
    }

    public String getCgjlb() {
        return cgjlb;
    }

    public void setCgjlb(String cgjlb) {
        this.cgjlb = cgjlb == null ? null : cgjlb.trim();
    }

    public String getCgjfs() {
        return cgjfs;
    }

    public void setCgjfs(String cgjfs) {
        this.cgjfs = cgjfs == null ? null : cgjfs.trim();
    }

    public String getYqdw() {
        return yqdw;
    }

    public void setYqdw(String yqdw) {
        this.yqdw = yqdw == null ? null : yqdw.trim();
    }

    public String getYqdwdz() {
        return yqdwdz;
    }

    public void setYqdwdz(String yqdwdz) {
        this.yqdwdz = yqdwdz == null ? null : yqdwdz.trim();
    }

    public String getYqr() {
        return yqr;
    }

    public void setYqr(String yqr) {
        this.yqr = yqr == null ? null : yqr.trim();
    }

    public String getSqrzc() {
        return sqrzc;
    }

    public void setSqrzc(String sqrzc) {
        this.sqrzc = sqrzc == null ? null : sqrzc.trim();
    }

    public String getSqrsjh() {
        return sqrsjh;
    }

    public void setSqrsjh(String sqrsjh) {
        this.sqrsjh = sqrsjh == null ? null : sqrsjh.trim();
    }

    public String getSqryx() {
        return sqryx;
    }

    public void setSqryx(String sqryx) {
        this.sqryx = sqryx == null ? null : sqryx.trim();
    }

    public Date getYjcfsj() {
        return yjcfsj;
    }

    public void setYjcfsj(Date yjcfsj) {
        this.yjcfsj = yjcfsj;
    }

    public Date getYgsj() {
        return ygsj;
    }

    public void setYgsj(Date ygsj) {
        this.ygsj = ygsj;
    }

    public Integer getYjtlts() {
        return yjtlts;
    }

    public void setYjtlts(Integer yjtlts) {
        this.yjtlts = yjtlts;
    }

    public Date getSjcfsj() {
        return sjcfsj;
    }

    public void setSjcfsj(Date sjcfsj) {
        this.sjcfsj = sjcfsj;
    }

    public Date getSgsj() {
        return sgsj;
    }

    public void setSgsj(Date sgsj) {
        this.sgsj = sgsj;
    }

    public Integer getSjtlts() {
        return sjtlts;
    }

    public void setSjtlts(Integer sjtlts) {
        this.sjtlts = sjtlts;
    }

    public Date getYq1s() {
        return yq1s;
    }

    public void setYq1s(Date yq1s) {
        this.yq1s = yq1s;
    }

    public Date getYq1z() {
        return yq1z;
    }

    public void setYq1z(Date yq1z) {
        this.yq1z = yq1z;
    }

    public Date getYq2s() {
        return yq2s;
    }

    public void setYq2s(Date yq2s) {
        this.yq2s = yq2s;
    }

    public Date getYq2z() {
        return yq2z;
    }

    public void setYq2z(Date yq2z) {
        this.yq2z = yq2z;
    }

    public Date getPzwh() {
        return pzwh;
    }

    public void setPzwh(Date pzwh) {
        this.pzwh = pzwh;
    }

    public String getCgjzt() {
        return cgjzt;
    }

    public void setCgjzt(String cgjzt) {
        this.cgjzt = cgjzt == null ? null : cgjzt.trim();
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public Byte getGender() {
        return gender;
    }

    public void setGender(Byte gender) {
        this.gender = gender;
    }

    public Integer getPartyId() {
        return partyId;
    }

    public void setPartyId(Integer partyId) {
        this.partyId = partyId;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }
}