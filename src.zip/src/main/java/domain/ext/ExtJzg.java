package domain.ext;

import java.io.Serializable;
import java.util.Date;

public class ExtJzg implements Serializable {
    private Integer id;

    private String zgh;

    private String xm;

    private String xbm;

    private String xb;

    private String dwdm;

    private String dwmc;

    private String yjxkm;

    private String yjxk;

    private Date lxrq;

    private String gwlbm;

    private String gwlb;

    private String zcm;

    private String zc;

    private String gwjbm;

    private String gwjb;

    private String rclxm;

    private String rclx;

    private String rcchm;

    private String rcch;

    private String xyjgm;

    private String xyjg;

    private String gjm;

    private String gj;

    private String zhxwm;

    private String zhxw;

    private String zhxl;

    private String zhxlmc;

    private String xlbyxx;

    private String xwsyxx;

    private String xzjbm;

    private String xzjb;

    private String sfzgm;

    private String sfzg;

    private String ryztm;

    private String ryzt;

    private String rylxm;

    private String rylx;

    private String bzlxm;

    private String bzlx;

    private Date csrq;

    private String rszfm;

    private String rszf;

    private String sfnxz;

    private String sfzjlx;

    private String name;

    private String sfzh;

    private String yddh;

    private String dzxx;

    private String bgdh;

    private String jtdh;

    private String zjgjm;

    private String zjgwdj;

    private String glgjm;

    private String glgwdj;

    private String empid;

    private String jg;

    private String zzmm;

    private String zw;

    private String zwmc;

    private String mz;

    private String xkmlm;

    private String xkml;

    private String ejxkm;

    private String ejxk;

    private String xmpy;

    private String poxm;

    private String ryxxshzt;

    private String tbrq;

    private String jzdw1;

    private String jzdw2;

    private String batchNum;

    private String basicActiveId;

    private String domainCode;

    private String basicActiveType;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getZgh() {
        return zgh;
    }

    public void setZgh(String zgh) {
        this.zgh = zgh == null ? null : zgh.trim();
    }

    public String getXm() {
        return xm;
    }

    public void setXm(String xm) {
        this.xm = xm == null ? null : xm.trim();
    }

    public String getXbm() {
        return xbm;
    }

    public void setXbm(String xbm) {
        this.xbm = xbm == null ? null : xbm.trim();
    }

    public String getXb() {
        return xb;
    }

    public void setXb(String xb) {
        this.xb = xb == null ? null : xb.trim();
    }

    public String getDwdm() {
        return dwdm;
    }

    public void setDwdm(String dwdm) {
        this.dwdm = dwdm == null ? null : dwdm.trim();
    }

    public String getDwmc() {
        return dwmc;
    }

    public void setDwmc(String dwmc) {
        this.dwmc = dwmc == null ? null : dwmc.trim();
    }

    public String getYjxkm() {
        return yjxkm;
    }

    public void setYjxkm(String yjxkm) {
        this.yjxkm = yjxkm == null ? null : yjxkm.trim();
    }

    public String getYjxk() {
        return yjxk;
    }

    public void setYjxk(String yjxk) {
        this.yjxk = yjxk == null ? null : yjxk.trim();
    }

    public Date getLxrq() {
        return lxrq;
    }

    public void setLxrq(Date lxrq) {
        this.lxrq = lxrq;
    }

    public String getGwlbm() {
        return gwlbm;
    }

    public void setGwlbm(String gwlbm) {
        this.gwlbm = gwlbm == null ? null : gwlbm.trim();
    }

    public String getGwlb() {
        return gwlb;
    }

    public void setGwlb(String gwlb) {
        this.gwlb = gwlb == null ? null : gwlb.trim();
    }

    public String getZcm() {
        return zcm;
    }

    public void setZcm(String zcm) {
        this.zcm = zcm == null ? null : zcm.trim();
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc == null ? null : zc.trim();
    }

    public String getGwjbm() {
        return gwjbm;
    }

    public void setGwjbm(String gwjbm) {
        this.gwjbm = gwjbm == null ? null : gwjbm.trim();
    }

    public String getGwjb() {
        return gwjb;
    }

    public void setGwjb(String gwjb) {
        this.gwjb = gwjb == null ? null : gwjb.trim();
    }

    public String getRclxm() {
        return rclxm;
    }

    public void setRclxm(String rclxm) {
        this.rclxm = rclxm == null ? null : rclxm.trim();
    }

    public String getRclx() {
        return rclx;
    }

    public void setRclx(String rclx) {
        this.rclx = rclx == null ? null : rclx.trim();
    }

    public String getRcchm() {
        return rcchm;
    }

    public void setRcchm(String rcchm) {
        this.rcchm = rcchm == null ? null : rcchm.trim();
    }

    public String getRcch() {
        return rcch;
    }

    public void setRcch(String rcch) {
        this.rcch = rcch == null ? null : rcch.trim();
    }

    public String getXyjgm() {
        return xyjgm;
    }

    public void setXyjgm(String xyjgm) {
        this.xyjgm = xyjgm == null ? null : xyjgm.trim();
    }

    public String getXyjg() {
        return xyjg;
    }

    public void setXyjg(String xyjg) {
        this.xyjg = xyjg == null ? null : xyjg.trim();
    }

    public String getGjm() {
        return gjm;
    }

    public void setGjm(String gjm) {
        this.gjm = gjm == null ? null : gjm.trim();
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj == null ? null : gj.trim();
    }

    public String getZhxwm() {
        return zhxwm;
    }

    public void setZhxwm(String zhxwm) {
        this.zhxwm = zhxwm == null ? null : zhxwm.trim();
    }

    public String getZhxw() {
        return zhxw;
    }

    public void setZhxw(String zhxw) {
        this.zhxw = zhxw == null ? null : zhxw.trim();
    }

    public String getZhxl() {
        return zhxl;
    }

    public void setZhxl(String zhxl) {
        this.zhxl = zhxl == null ? null : zhxl.trim();
    }

    public String getZhxlmc() {
        return zhxlmc;
    }

    public void setZhxlmc(String zhxlmc) {
        this.zhxlmc = zhxlmc == null ? null : zhxlmc.trim();
    }

    public String getXlbyxx() {
        return xlbyxx;
    }

    public void setXlbyxx(String xlbyxx) {
        this.xlbyxx = xlbyxx == null ? null : xlbyxx.trim();
    }

    public String getXwsyxx() {
        return xwsyxx;
    }

    public void setXwsyxx(String xwsyxx) {
        this.xwsyxx = xwsyxx == null ? null : xwsyxx.trim();
    }

    public String getXzjbm() {
        return xzjbm;
    }

    public void setXzjbm(String xzjbm) {
        this.xzjbm = xzjbm == null ? null : xzjbm.trim();
    }

    public String getXzjb() {
        return xzjb;
    }

    public void setXzjb(String xzjb) {
        this.xzjb = xzjb == null ? null : xzjb.trim();
    }

    public String getSfzgm() {
        return sfzgm;
    }

    public void setSfzgm(String sfzgm) {
        this.sfzgm = sfzgm == null ? null : sfzgm.trim();
    }

    public String getSfzg() {
        return sfzg;
    }

    public void setSfzg(String sfzg) {
        this.sfzg = sfzg == null ? null : sfzg.trim();
    }

    public String getRyztm() {
        return ryztm;
    }

    public void setRyztm(String ryztm) {
        this.ryztm = ryztm == null ? null : ryztm.trim();
    }

    public String getRyzt() {
        return ryzt;
    }

    public void setRyzt(String ryzt) {
        this.ryzt = ryzt == null ? null : ryzt.trim();
    }

    public String getRylxm() {
        return rylxm;
    }

    public void setRylxm(String rylxm) {
        this.rylxm = rylxm == null ? null : rylxm.trim();
    }

    public String getRylx() {
        return rylx;
    }

    public void setRylx(String rylx) {
        this.rylx = rylx == null ? null : rylx.trim();
    }

    public String getBzlxm() {
        return bzlxm;
    }

    public void setBzlxm(String bzlxm) {
        this.bzlxm = bzlxm == null ? null : bzlxm.trim();
    }

    public String getBzlx() {
        return bzlx;
    }

    public void setBzlx(String bzlx) {
        this.bzlx = bzlx == null ? null : bzlx.trim();
    }

    public Date getCsrq() {
        return csrq;
    }

    public void setCsrq(Date csrq) {
        this.csrq = csrq;
    }

    public String getRszfm() {
        return rszfm;
    }

    public void setRszfm(String rszfm) {
        this.rszfm = rszfm == null ? null : rszfm.trim();
    }

    public String getRszf() {
        return rszf;
    }

    public void setRszf(String rszf) {
        this.rszf = rszf == null ? null : rszf.trim();
    }

    public String getSfnxz() {
        return sfnxz;
    }

    public void setSfnxz(String sfnxz) {
        this.sfnxz = sfnxz == null ? null : sfnxz.trim();
    }

    public String getSfzjlx() {
        return sfzjlx;
    }

    public void setSfzjlx(String sfzjlx) {
        this.sfzjlx = sfzjlx == null ? null : sfzjlx.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getSfzh() {
        return sfzh;
    }

    public void setSfzh(String sfzh) {
        this.sfzh = sfzh == null ? null : sfzh.trim();
    }

    public String getYddh() {
        return yddh;
    }

    public void setYddh(String yddh) {
        this.yddh = yddh == null ? null : yddh.trim();
    }

    public String getDzxx() {
        return dzxx;
    }

    public void setDzxx(String dzxx) {
        this.dzxx = dzxx == null ? null : dzxx.trim();
    }

    public String getBgdh() {
        return bgdh;
    }

    public void setBgdh(String bgdh) {
        this.bgdh = bgdh == null ? null : bgdh.trim();
    }

    public String getJtdh() {
        return jtdh;
    }

    public void setJtdh(String jtdh) {
        this.jtdh = jtdh == null ? null : jtdh.trim();
    }

    public String getZjgjm() {
        return zjgjm;
    }

    public void setZjgjm(String zjgjm) {
        this.zjgjm = zjgjm == null ? null : zjgjm.trim();
    }

    public String getZjgwdj() {
        return zjgwdj;
    }

    public void setZjgwdj(String zjgwdj) {
        this.zjgwdj = zjgwdj == null ? null : zjgwdj.trim();
    }

    public String getGlgjm() {
        return glgjm;
    }

    public void setGlgjm(String glgjm) {
        this.glgjm = glgjm == null ? null : glgjm.trim();
    }

    public String getGlgwdj() {
        return glgwdj;
    }

    public void setGlgwdj(String glgwdj) {
        this.glgwdj = glgwdj == null ? null : glgwdj.trim();
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid == null ? null : empid.trim();
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg == null ? null : jg.trim();
    }

    public String getZzmm() {
        return zzmm;
    }

    public void setZzmm(String zzmm) {
        this.zzmm = zzmm == null ? null : zzmm.trim();
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw == null ? null : zw.trim();
    }

    public String getZwmc() {
        return zwmc;
    }

    public void setZwmc(String zwmc) {
        this.zwmc = zwmc == null ? null : zwmc.trim();
    }

    public String getMz() {
        return mz;
    }

    public void setMz(String mz) {
        this.mz = mz == null ? null : mz.trim();
    }

    public String getXkmlm() {
        return xkmlm;
    }

    public void setXkmlm(String xkmlm) {
        this.xkmlm = xkmlm == null ? null : xkmlm.trim();
    }

    public String getXkml() {
        return xkml;
    }

    public void setXkml(String xkml) {
        this.xkml = xkml == null ? null : xkml.trim();
    }

    public String getEjxkm() {
        return ejxkm;
    }

    public void setEjxkm(String ejxkm) {
        this.ejxkm = ejxkm == null ? null : ejxkm.trim();
    }

    public String getEjxk() {
        return ejxk;
    }

    public void setEjxk(String ejxk) {
        this.ejxk = ejxk == null ? null : ejxk.trim();
    }

    public String getXmpy() {
        return xmpy;
    }

    public void setXmpy(String xmpy) {
        this.xmpy = xmpy == null ? null : xmpy.trim();
    }

    public String getPoxm() {
        return poxm;
    }

    public void setPoxm(String poxm) {
        this.poxm = poxm == null ? null : poxm.trim();
    }

    public String getRyxxshzt() {
        return ryxxshzt;
    }

    public void setRyxxshzt(String ryxxshzt) {
        this.ryxxshzt = ryxxshzt == null ? null : ryxxshzt.trim();
    }

    public String getTbrq() {
        return tbrq;
    }

    public void setTbrq(String tbrq) {
        this.tbrq = tbrq == null ? null : tbrq.trim();
    }

    public String getJzdw1() {
        return jzdw1;
    }

    public void setJzdw1(String jzdw1) {
        this.jzdw1 = jzdw1 == null ? null : jzdw1.trim();
    }

    public String getJzdw2() {
        return jzdw2;
    }

    public void setJzdw2(String jzdw2) {
        this.jzdw2 = jzdw2 == null ? null : jzdw2.trim();
    }

    public String getBatchNum() {
        return batchNum;
    }

    public void setBatchNum(String batchNum) {
        this.batchNum = batchNum == null ? null : batchNum.trim();
    }

    public String getBasicActiveId() {
        return basicActiveId;
    }

    public void setBasicActiveId(String basicActiveId) {
        this.basicActiveId = basicActiveId == null ? null : basicActiveId.trim();
    }

    public String getDomainCode() {
        return domainCode;
    }

    public void setDomainCode(String domainCode) {
        this.domainCode = domainCode == null ? null : domainCode.trim();
    }

    public String getBasicActiveType() {
        return basicActiveType;
    }

    public void setBasicActiveType(String basicActiveType) {
        this.basicActiveType = basicActiveType == null ? null : basicActiveType.trim();
    }
}