package domain.ext;

import java.io.Serializable;

public class ExtYjs implements Serializable {
    private Integer id;

    private String xh;

    private String ztm;

    private String zt;

    private String gbm;

    private String gb;

    private String xslbm2;

    private String xslb;

    private String xm;

    private String xmpy;

    private String xbm;

    private String xb;

    private String csrq;

    private String sfzh;

    private String mzm;

    private String mz;

    private String pyccm;

    private String pycc;

    private String pylxm;

    private String pylx;

    private String jylbm;

    private String jylb;

    private String pyfsm;

    private String pyfs;

    private String ksh;

    private String yxsh;

    private String yxsm;

    private String yxsmc;

    private String yjxkm;

    private String yjxkmc;

    private String zydm;

    private String zymc;

    private String yjfxm;

    private String yjfxmc;

    private String dsh;

    private String dsxm;

    private String lqlbm;

    private String lqlb;

    private String dxwpdw;

    private String daszdw;

    private Integer zsnd;

    private Integer blzgnx;

    private String blzgm;

    private Integer nj;

    private Integer xz;

    private String yjrxny;

    private String sjrxny;

    private String yjbyny;

    private Float yqbynx;

    private String sjbyny;

    private String sjxwny;

    private String xjglm;

    private String xjglmc;

    private String xjglny;

    private String xjbz;

    private String xjydbz;

    private String qtbz;

    private String hkszdm;

    private String syszdm;

    private String xxgzdw;

    private String zslqlbm;

    private String zslqlb;

    private String zxjhm;

    private String ksfsm;

    private String ksfs;

    private String kslym;

    private String ksly;

    private String pyzxjhm;

    private String pyzxjh;

    private String zzmmm;

    private String hfm;

    private String xyjrm;

    private String xslbm5;

    private String tjzydm;

    private String tjzymc;

    private String ksh16;

    private String sjcqsj;

    private String qzdwm;

    private String qzdw;

    private String qzny;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getXh() {
        return xh;
    }

    public void setXh(String xh) {
        this.xh = xh == null ? null : xh.trim();
    }

    public String getZtm() {
        return ztm;
    }

    public void setZtm(String ztm) {
        this.ztm = ztm == null ? null : ztm.trim();
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt == null ? null : zt.trim();
    }

    public String getGbm() {
        return gbm;
    }

    public void setGbm(String gbm) {
        this.gbm = gbm == null ? null : gbm.trim();
    }

    public String getGb() {
        return gb;
    }

    public void setGb(String gb) {
        this.gb = gb == null ? null : gb.trim();
    }

    public String getXslbm2() {
        return xslbm2;
    }

    public void setXslbm2(String xslbm2) {
        this.xslbm2 = xslbm2 == null ? null : xslbm2.trim();
    }

    public String getXslb() {
        return xslb;
    }

    public void setXslb(String xslb) {
        this.xslb = xslb == null ? null : xslb.trim();
    }

    public String getXm() {
        return xm;
    }

    public void setXm(String xm) {
        this.xm = xm == null ? null : xm.trim();
    }

    public String getXmpy() {
        return xmpy;
    }

    public void setXmpy(String xmpy) {
        this.xmpy = xmpy == null ? null : xmpy.trim();
    }

    public String getXbm() {
        return xbm;
    }

    public void setXbm(String xbm) {
        this.xbm = xbm == null ? null : xbm.trim();
    }

    public String getXb() {
        return xb;
    }

    public void setXb(String xb) {
        this.xb = xb == null ? null : xb.trim();
    }

    public String getCsrq() {
        return csrq;
    }

    public void setCsrq(String csrq) {
        this.csrq = csrq == null ? null : csrq.trim();
    }

    public String getSfzh() {
        return sfzh;
    }

    public void setSfzh(String sfzh) {
        this.sfzh = sfzh == null ? null : sfzh.trim();
    }

    public String getMzm() {
        return mzm;
    }

    public void setMzm(String mzm) {
        this.mzm = mzm == null ? null : mzm.trim();
    }

    public String getMz() {
        return mz;
    }

    public void setMz(String mz) {
        this.mz = mz == null ? null : mz.trim();
    }

    public String getPyccm() {
        return pyccm;
    }

    public void setPyccm(String pyccm) {
        this.pyccm = pyccm == null ? null : pyccm.trim();
    }

    public String getPycc() {
        return pycc;
    }

    public void setPycc(String pycc) {
        this.pycc = pycc == null ? null : pycc.trim();
    }

    public String getPylxm() {
        return pylxm;
    }

    public void setPylxm(String pylxm) {
        this.pylxm = pylxm == null ? null : pylxm.trim();
    }

    public String getPylx() {
        return pylx;
    }

    public void setPylx(String pylx) {
        this.pylx = pylx == null ? null : pylx.trim();
    }

    public String getJylbm() {
        return jylbm;
    }

    public void setJylbm(String jylbm) {
        this.jylbm = jylbm == null ? null : jylbm.trim();
    }

    public String getJylb() {
        return jylb;
    }

    public void setJylb(String jylb) {
        this.jylb = jylb == null ? null : jylb.trim();
    }

    public String getPyfsm() {
        return pyfsm;
    }

    public void setPyfsm(String pyfsm) {
        this.pyfsm = pyfsm == null ? null : pyfsm.trim();
    }

    public String getPyfs() {
        return pyfs;
    }

    public void setPyfs(String pyfs) {
        this.pyfs = pyfs == null ? null : pyfs.trim();
    }

    public String getKsh() {
        return ksh;
    }

    public void setKsh(String ksh) {
        this.ksh = ksh == null ? null : ksh.trim();
    }

    public String getYxsh() {
        return yxsh;
    }

    public void setYxsh(String yxsh) {
        this.yxsh = yxsh == null ? null : yxsh.trim();
    }

    public String getYxsm() {
        return yxsm;
    }

    public void setYxsm(String yxsm) {
        this.yxsm = yxsm == null ? null : yxsm.trim();
    }

    public String getYxsmc() {
        return yxsmc;
    }

    public void setYxsmc(String yxsmc) {
        this.yxsmc = yxsmc == null ? null : yxsmc.trim();
    }

    public String getYjxkm() {
        return yjxkm;
    }

    public void setYjxkm(String yjxkm) {
        this.yjxkm = yjxkm == null ? null : yjxkm.trim();
    }

    public String getYjxkmc() {
        return yjxkmc;
    }

    public void setYjxkmc(String yjxkmc) {
        this.yjxkmc = yjxkmc == null ? null : yjxkmc.trim();
    }

    public String getZydm() {
        return zydm;
    }

    public void setZydm(String zydm) {
        this.zydm = zydm == null ? null : zydm.trim();
    }

    public String getZymc() {
        return zymc;
    }

    public void setZymc(String zymc) {
        this.zymc = zymc == null ? null : zymc.trim();
    }

    public String getYjfxm() {
        return yjfxm;
    }

    public void setYjfxm(String yjfxm) {
        this.yjfxm = yjfxm == null ? null : yjfxm.trim();
    }

    public String getYjfxmc() {
        return yjfxmc;
    }

    public void setYjfxmc(String yjfxmc) {
        this.yjfxmc = yjfxmc == null ? null : yjfxmc.trim();
    }

    public String getDsh() {
        return dsh;
    }

    public void setDsh(String dsh) {
        this.dsh = dsh == null ? null : dsh.trim();
    }

    public String getDsxm() {
        return dsxm;
    }

    public void setDsxm(String dsxm) {
        this.dsxm = dsxm == null ? null : dsxm.trim();
    }

    public String getLqlbm() {
        return lqlbm;
    }

    public void setLqlbm(String lqlbm) {
        this.lqlbm = lqlbm == null ? null : lqlbm.trim();
    }

    public String getLqlb() {
        return lqlb;
    }

    public void setLqlb(String lqlb) {
        this.lqlb = lqlb == null ? null : lqlb.trim();
    }

    public String getDxwpdw() {
        return dxwpdw;
    }

    public void setDxwpdw(String dxwpdw) {
        this.dxwpdw = dxwpdw == null ? null : dxwpdw.trim();
    }

    public String getDaszdw() {
        return daszdw;
    }

    public void setDaszdw(String daszdw) {
        this.daszdw = daszdw == null ? null : daszdw.trim();
    }

    public Integer getZsnd() {
        return zsnd;
    }

    public void setZsnd(Integer zsnd) {
        this.zsnd = zsnd;
    }

    public Integer getBlzgnx() {
        return blzgnx;
    }

    public void setBlzgnx(Integer blzgnx) {
        this.blzgnx = blzgnx;
    }

    public String getBlzgm() {
        return blzgm;
    }

    public void setBlzgm(String blzgm) {
        this.blzgm = blzgm == null ? null : blzgm.trim();
    }

    public Integer getNj() {
        return nj;
    }

    public void setNj(Integer nj) {
        this.nj = nj;
    }

    public Integer getXz() {
        return xz;
    }

    public void setXz(Integer xz) {
        this.xz = xz;
    }

    public String getYjrxny() {
        return yjrxny;
    }

    public void setYjrxny(String yjrxny) {
        this.yjrxny = yjrxny == null ? null : yjrxny.trim();
    }

    public String getSjrxny() {
        return sjrxny;
    }

    public void setSjrxny(String sjrxny) {
        this.sjrxny = sjrxny == null ? null : sjrxny.trim();
    }

    public String getYjbyny() {
        return yjbyny;
    }

    public void setYjbyny(String yjbyny) {
        this.yjbyny = yjbyny == null ? null : yjbyny.trim();
    }

    public Float getYqbynx() {
        return yqbynx;
    }

    public void setYqbynx(Float yqbynx) {
        this.yqbynx = yqbynx;
    }

    public String getSjbyny() {
        return sjbyny;
    }

    public void setSjbyny(String sjbyny) {
        this.sjbyny = sjbyny == null ? null : sjbyny.trim();
    }

    public String getSjxwny() {
        return sjxwny;
    }

    public void setSjxwny(String sjxwny) {
        this.sjxwny = sjxwny == null ? null : sjxwny.trim();
    }

    public String getXjglm() {
        return xjglm;
    }

    public void setXjglm(String xjglm) {
        this.xjglm = xjglm == null ? null : xjglm.trim();
    }

    public String getXjglmc() {
        return xjglmc;
    }

    public void setXjglmc(String xjglmc) {
        this.xjglmc = xjglmc == null ? null : xjglmc.trim();
    }

    public String getXjglny() {
        return xjglny;
    }

    public void setXjglny(String xjglny) {
        this.xjglny = xjglny == null ? null : xjglny.trim();
    }

    public String getXjbz() {
        return xjbz;
    }

    public void setXjbz(String xjbz) {
        this.xjbz = xjbz == null ? null : xjbz.trim();
    }

    public String getXjydbz() {
        return xjydbz;
    }

    public void setXjydbz(String xjydbz) {
        this.xjydbz = xjydbz == null ? null : xjydbz.trim();
    }

    public String getQtbz() {
        return qtbz;
    }

    public void setQtbz(String qtbz) {
        this.qtbz = qtbz == null ? null : qtbz.trim();
    }

    public String getHkszdm() {
        return hkszdm;
    }

    public void setHkszdm(String hkszdm) {
        this.hkszdm = hkszdm == null ? null : hkszdm.trim();
    }

    public String getSyszdm() {
        return syszdm;
    }

    public void setSyszdm(String syszdm) {
        this.syszdm = syszdm == null ? null : syszdm.trim();
    }

    public String getXxgzdw() {
        return xxgzdw;
    }

    public void setXxgzdw(String xxgzdw) {
        this.xxgzdw = xxgzdw == null ? null : xxgzdw.trim();
    }

    public String getZslqlbm() {
        return zslqlbm;
    }

    public void setZslqlbm(String zslqlbm) {
        this.zslqlbm = zslqlbm == null ? null : zslqlbm.trim();
    }

    public String getZslqlb() {
        return zslqlb;
    }

    public void setZslqlb(String zslqlb) {
        this.zslqlb = zslqlb == null ? null : zslqlb.trim();
    }

    public String getZxjhm() {
        return zxjhm;
    }

    public void setZxjhm(String zxjhm) {
        this.zxjhm = zxjhm == null ? null : zxjhm.trim();
    }

    public String getKsfsm() {
        return ksfsm;
    }

    public void setKsfsm(String ksfsm) {
        this.ksfsm = ksfsm == null ? null : ksfsm.trim();
    }

    public String getKsfs() {
        return ksfs;
    }

    public void setKsfs(String ksfs) {
        this.ksfs = ksfs == null ? null : ksfs.trim();
    }

    public String getKslym() {
        return kslym;
    }

    public void setKslym(String kslym) {
        this.kslym = kslym == null ? null : kslym.trim();
    }

    public String getKsly() {
        return ksly;
    }

    public void setKsly(String ksly) {
        this.ksly = ksly == null ? null : ksly.trim();
    }

    public String getPyzxjhm() {
        return pyzxjhm;
    }

    public void setPyzxjhm(String pyzxjhm) {
        this.pyzxjhm = pyzxjhm == null ? null : pyzxjhm.trim();
    }

    public String getPyzxjh() {
        return pyzxjh;
    }

    public void setPyzxjh(String pyzxjh) {
        this.pyzxjh = pyzxjh == null ? null : pyzxjh.trim();
    }

    public String getZzmmm() {
        return zzmmm;
    }

    public void setZzmmm(String zzmmm) {
        this.zzmmm = zzmmm == null ? null : zzmmm.trim();
    }

    public String getHfm() {
        return hfm;
    }

    public void setHfm(String hfm) {
        this.hfm = hfm == null ? null : hfm.trim();
    }

    public String getXyjrm() {
        return xyjrm;
    }

    public void setXyjrm(String xyjrm) {
        this.xyjrm = xyjrm == null ? null : xyjrm.trim();
    }

    public String getXslbm5() {
        return xslbm5;
    }

    public void setXslbm5(String xslbm5) {
        this.xslbm5 = xslbm5 == null ? null : xslbm5.trim();
    }

    public String getTjzydm() {
        return tjzydm;
    }

    public void setTjzydm(String tjzydm) {
        this.tjzydm = tjzydm == null ? null : tjzydm.trim();
    }

    public String getTjzymc() {
        return tjzymc;
    }

    public void setTjzymc(String tjzymc) {
        this.tjzymc = tjzymc == null ? null : tjzymc.trim();
    }

    public String getKsh16() {
        return ksh16;
    }

    public void setKsh16(String ksh16) {
        this.ksh16 = ksh16 == null ? null : ksh16.trim();
    }

    public String getSjcqsj() {
        return sjcqsj;
    }

    public void setSjcqsj(String sjcqsj) {
        this.sjcqsj = sjcqsj == null ? null : sjcqsj.trim();
    }

    public String getQzdwm() {
        return qzdwm;
    }

    public void setQzdwm(String qzdwm) {
        this.qzdwm = qzdwm == null ? null : qzdwm.trim();
    }

    public String getQzdw() {
        return qzdw;
    }

    public void setQzdw(String qzdw) {
        this.qzdw = qzdw == null ? null : qzdw.trim();
    }

    public String getQzny() {
        return qzny;
    }

    public void setQzny(String qzny) {
        this.qzny = qzny == null ? null : qzny.trim();
    }
}