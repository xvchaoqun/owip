package domain.ext;

import java.io.Serializable;

public class ExtBks implements Serializable {
    private Integer id;

    private String xh;

    private String xm;

    private String xb;

    private String csrq;

    private String nj;

    private String yxmc;

    private String zymc;

    private String fgyx;

    private String pyfs;

    private String mz;

    private String zzmm;

    private String xjbd;

    private String xjrq;

    private String xjyy;

    private String sf;

    private String dq;

    private String syxx;

    private String dxhwpdw;

    private String dxdwszd;

    private String ksh;

    private String xmpy;

    private String kslb;

    private String wyyz;

    private String jtdz;

    private String yzbm;

    private String lxdh;

    private String kl;

    private String lqzymc;

    private String lqyxmc;

    private String mfsfs;

    private String sfzh;

    private String kstc;

    private String grpj;

    private String ksjl;

    private String xkml;

    private String zkzh;

    private String byxx;

    private String bz;

    private String sfgfs;

    private String importTimeMillis;

    private String yxsh;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getXh() {
        return xh;
    }

    public void setXh(String xh) {
        this.xh = xh == null ? null : xh.trim();
    }

    public String getXm() {
        return xm;
    }

    public void setXm(String xm) {
        this.xm = xm == null ? null : xm.trim();
    }

    public String getXb() {
        return xb;
    }

    public void setXb(String xb) {
        this.xb = xb == null ? null : xb.trim();
    }

    public String getCsrq() {
        return csrq;
    }

    public void setCsrq(String csrq) {
        this.csrq = csrq == null ? null : csrq.trim();
    }

    public String getNj() {
        return nj;
    }

    public void setNj(String nj) {
        this.nj = nj == null ? null : nj.trim();
    }

    public String getYxmc() {
        return yxmc;
    }

    public void setYxmc(String yxmc) {
        this.yxmc = yxmc == null ? null : yxmc.trim();
    }

    public String getZymc() {
        return zymc;
    }

    public void setZymc(String zymc) {
        this.zymc = zymc == null ? null : zymc.trim();
    }

    public String getFgyx() {
        return fgyx;
    }

    public void setFgyx(String fgyx) {
        this.fgyx = fgyx == null ? null : fgyx.trim();
    }

    public String getPyfs() {
        return pyfs;
    }

    public void setPyfs(String pyfs) {
        this.pyfs = pyfs == null ? null : pyfs.trim();
    }

    public String getMz() {
        return mz;
    }

    public void setMz(String mz) {
        this.mz = mz == null ? null : mz.trim();
    }

    public String getZzmm() {
        return zzmm;
    }

    public void setZzmm(String zzmm) {
        this.zzmm = zzmm == null ? null : zzmm.trim();
    }

    public String getXjbd() {
        return xjbd;
    }

    public void setXjbd(String xjbd) {
        this.xjbd = xjbd == null ? null : xjbd.trim();
    }

    public String getXjrq() {
        return xjrq;
    }

    public void setXjrq(String xjrq) {
        this.xjrq = xjrq == null ? null : xjrq.trim();
    }

    public String getXjyy() {
        return xjyy;
    }

    public void setXjyy(String xjyy) {
        this.xjyy = xjyy == null ? null : xjyy.trim();
    }

    public String getSf() {
        return sf;
    }

    public void setSf(String sf) {
        this.sf = sf == null ? null : sf.trim();
    }

    public String getDq() {
        return dq;
    }

    public void setDq(String dq) {
        this.dq = dq == null ? null : dq.trim();
    }

    public String getSyxx() {
        return syxx;
    }

    public void setSyxx(String syxx) {
        this.syxx = syxx == null ? null : syxx.trim();
    }

    public String getDxhwpdw() {
        return dxhwpdw;
    }

    public void setDxhwpdw(String dxhwpdw) {
        this.dxhwpdw = dxhwpdw == null ? null : dxhwpdw.trim();
    }

    public String getDxdwszd() {
        return dxdwszd;
    }

    public void setDxdwszd(String dxdwszd) {
        this.dxdwszd = dxdwszd == null ? null : dxdwszd.trim();
    }

    public String getKsh() {
        return ksh;
    }

    public void setKsh(String ksh) {
        this.ksh = ksh == null ? null : ksh.trim();
    }

    public String getXmpy() {
        return xmpy;
    }

    public void setXmpy(String xmpy) {
        this.xmpy = xmpy == null ? null : xmpy.trim();
    }

    public String getKslb() {
        return kslb;
    }

    public void setKslb(String kslb) {
        this.kslb = kslb == null ? null : kslb.trim();
    }

    public String getWyyz() {
        return wyyz;
    }

    public void setWyyz(String wyyz) {
        this.wyyz = wyyz == null ? null : wyyz.trim();
    }

    public String getJtdz() {
        return jtdz;
    }

    public void setJtdz(String jtdz) {
        this.jtdz = jtdz == null ? null : jtdz.trim();
    }

    public String getYzbm() {
        return yzbm;
    }

    public void setYzbm(String yzbm) {
        this.yzbm = yzbm == null ? null : yzbm.trim();
    }

    public String getLxdh() {
        return lxdh;
    }

    public void setLxdh(String lxdh) {
        this.lxdh = lxdh == null ? null : lxdh.trim();
    }

    public String getKl() {
        return kl;
    }

    public void setKl(String kl) {
        this.kl = kl == null ? null : kl.trim();
    }

    public String getLqzymc() {
        return lqzymc;
    }

    public void setLqzymc(String lqzymc) {
        this.lqzymc = lqzymc == null ? null : lqzymc.trim();
    }

    public String getLqyxmc() {
        return lqyxmc;
    }

    public void setLqyxmc(String lqyxmc) {
        this.lqyxmc = lqyxmc == null ? null : lqyxmc.trim();
    }

    public String getMfsfs() {
        return mfsfs;
    }

    public void setMfsfs(String mfsfs) {
        this.mfsfs = mfsfs == null ? null : mfsfs.trim();
    }

    public String getSfzh() {
        return sfzh;
    }

    public void setSfzh(String sfzh) {
        this.sfzh = sfzh == null ? null : sfzh.trim();
    }

    public String getKstc() {
        return kstc;
    }

    public void setKstc(String kstc) {
        this.kstc = kstc == null ? null : kstc.trim();
    }

    public String getGrpj() {
        return grpj;
    }

    public void setGrpj(String grpj) {
        this.grpj = grpj == null ? null : grpj.trim();
    }

    public String getKsjl() {
        return ksjl;
    }

    public void setKsjl(String ksjl) {
        this.ksjl = ksjl == null ? null : ksjl.trim();
    }

    public String getXkml() {
        return xkml;
    }

    public void setXkml(String xkml) {
        this.xkml = xkml == null ? null : xkml.trim();
    }

    public String getZkzh() {
        return zkzh;
    }

    public void setZkzh(String zkzh) {
        this.zkzh = zkzh == null ? null : zkzh.trim();
    }

    public String getByxx() {
        return byxx;
    }

    public void setByxx(String byxx) {
        this.byxx = byxx == null ? null : byxx.trim();
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz == null ? null : bz.trim();
    }

    public String getSfgfs() {
        return sfgfs;
    }

    public void setSfgfs(String sfgfs) {
        this.sfgfs = sfgfs == null ? null : sfgfs.trim();
    }

    public String getImportTimeMillis() {
        return importTimeMillis;
    }

    public void setImportTimeMillis(String importTimeMillis) {
        this.importTimeMillis = importTimeMillis == null ? null : importTimeMillis.trim();
    }

    public String getYxsh() {
        return yxsh;
    }

    public void setYxsh(String yxsh) {
        this.yxsh = yxsh == null ? null : yxsh.trim();
    }
}