package interceptor;

/**
 * Created by fafa on 2015/9/9.
 */
public class SignParamsException extends RuntimeException {

    public SignParamsException(String message) {
        super(message);
    }
}
