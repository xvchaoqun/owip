package bean;

/**
 * Created by fafa on 2016/6/22.
 */
public class ApplySelfModifyBean {
    private String modifyProof;
    private String modifyProofFileName;
    private String remark;

    public String getModifyProof() {
        return modifyProof;
    }

    public void setModifyProof(String modifyProof) {
        this.modifyProof = modifyProof;
    }

    public String getModifyProofFileName() {
        return modifyProofFileName;
    }

    public void setModifyProofFileName(String modifyProofFileName) {
        this.modifyProofFileName = modifyProofFileName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
