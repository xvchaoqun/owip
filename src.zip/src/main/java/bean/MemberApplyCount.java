package bean;

/**
 * Created by fafa on 2016/5/25.
 */
public class MemberApplyCount {
    private Byte type;
    private Byte stage;
    private Integer  num;

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Byte getStage() {
        return stage;
    }

    public void setStage(Byte stage) {
        this.stage = stage;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }
}
